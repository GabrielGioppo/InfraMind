from rest_framework import generics
from django.contrib.auth import get_user_model
from users.serializers import UserSerializer

User = get_user_model()

class UserCreateListView(generics.ListCreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer

class UserRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer