from django.db import models
from users.models import User
from categories.models import Category

class Occurrence(models.Model):
    """Model principal para ocorrências"""
    
    STATUS_CHOICES = [
        ('open', 'Aberta'),
        ('in_progress', 'Em Andamento'),
        ('resolved', 'Resolvida'),
        ('closed', 'Fechada'),
    ]
    
    # Relacionamentos
    user = models.ForeignKey(
        User, 
        on_delete=models.RESTRICT, 
        related_name='occurrences'
    )
    category = models.ForeignKey(
        Category,
        on_delete=models.RESTRICT,
        related_name='occurrences',
        null=True,
        blank=True
    )
    
    # Dados da ocorrência
    title = models.CharField(max_length=200)
    description = models.TextField()
    latitude = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    longitude = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    address = models.TextField(blank=True, null=True)
    
    # Status e controle
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='open')
    priority = models.IntegerField(default=0)  # 0 = baixa, 1 = média, 2 = alta, 3 = urgente
    estimated_time = models.IntegerField(null=True, blank=True)  # Tempo estimado em horas
    is_duplicate = models.BooleanField(default=False)
    duplicate_of = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='duplicates'
    )
    
    # Datas
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    
    # Validações
    validation_count = models.IntegerField(default=0)
    
    def __str__(self):
        return f"{self.title} - {self.status}"