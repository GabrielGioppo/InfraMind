from rest_framework import serializers
from occurrences.models import Occurrence
from users.serializers import UserSerializer
from categories.serializers import CategorySerializer

class OccurrenceSerializer(serializers.ModelSerializer):
    user_details = UserSerializer(source='user', read_only=True)
    category_details = CategorySerializer(source='category', read_only=True)
    
    class Meta:
        model = Occurrence
        fields = '__all__'
        read_only_fields = ['user', 'validation_count', 'priority', 'is_duplicate']