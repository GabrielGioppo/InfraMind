from rest_framework import generics
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.db.models import Q
from occurrences.models import Occurrence
from occurrences.serializers import OccurrenceSerializer

class OccurrenceCreateListView(generics.ListCreateAPIView):
    queryset = Occurrence.objects.all()
    serializer_class = OccurrenceSerializer

class OccurrenceRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Occurrence.objects.all()
    serializer_class = OccurrenceSerializer

# View para buscar ocorrências próximas
@api_view(['GET'])
def nearby_occurrences(request, lat, lng, radius_km=1):
    # Simplificação: busca por latitude e longitude aproximadas
    # Em produção, usar cálculos mais precisos ou extensão PostGIS
    occurrences = Occurrence.objects.filter(
        Q(latitude__isnull=False),
        Q(longitude__isnull=False)
    )
    # Filtro simplificado
    result = [
        occ for occ in occurrences 
        if abs(float(occ.latitude) - float(lat)) < float(radius_km)/111 and
           abs(float(occ.longitude) - float(lng)) < float(radius_km)/111
    ]
    serializer = OccurrenceSerializer(result, many=True)
    return Response(serializer.data)