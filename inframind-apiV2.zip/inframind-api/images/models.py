from django.db import models
from occurrences.models import Occurrence

class Image(models.Model):
    """Model para imagens das ocorrências"""
    
    occurrence = models.ForeignKey(
        Occurrence,
        on_delete=models.CASCADE,
        related_name='images'
    )
    image = models.ImageField(upload_to='occurrences/%Y/%m/%d/')
    caption = models.CharField(max_length=200, blank=True, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Image for {self.occurrence.title}"