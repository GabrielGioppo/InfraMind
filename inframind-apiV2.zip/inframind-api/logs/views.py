from rest_framework import generics
from logs.models import Log
from logs.serializers import LogSerializer

class LogCreateListView(generics.ListCreateAPIView):
    queryset = Log.objects.all()
    serializer_class = LogSerializer

class LogRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Log.objects.all()
    serializer_class = LogSerializer