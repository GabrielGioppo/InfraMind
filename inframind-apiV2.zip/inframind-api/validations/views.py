from rest_framework import generics
from rest_framework.response import Response
from rest_framework.decorators import api_view
from validations.models import Validation
from validations.serializers import ValidationSerializer
from occurrences.models import Occurrence

class ValidationCreateListView(generics.ListCreateAPIView):
    queryset = Validation.objects.all()
    serializer_class = ValidationSerializer

# View para validar uma ocorrência
@api_view(['POST'])
def validate_occurrence(request, occurrence_id, user_id):
    # Verificar se já existe validação
    existing = Validation.objects.filter(
        occurrence_id=occurrence_id, 
        user_id=user_id
    ).first()
    
    if existing:
        return Response({"error": "Usuário já validou esta ocorrência"}, status=400)
    
    # Criar validação
    validation = Validation.objects.create(
        user_id=user_id,
        occurrence_id=occurrence_id
    )
    
    # Atualizar contador da ocorrência
    occurrence = Occurrence.objects.get(id=occurrence_id)
    occurrence.validation_count += 1
    occurrence.save()
    
    serializer = ValidationSerializer(validation)
    return Response(serializer.data)