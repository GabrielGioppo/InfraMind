from django.db import models
from users.models import User
from occurrences.models import Occurrence

class Feedback(models.Model):
    """Model para feedbacks após resolução"""
    
    user = models.ForeignKey(
        User,
        on_delete=models.RESTRICT,
        related_name='feedbacks'
    )
    occurrence = models.ForeignKey(
        Occurrence,
        on_delete=models.CASCADE,
        related_name='feedbacks'
    )
    comment = models.TextField()
    rating = models.IntegerField(choices=[(i, i) for i in range(1, 6)])  # 1 a 5 estrelas
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Feedback de {self.user.username} - Nota: {self.rating}"