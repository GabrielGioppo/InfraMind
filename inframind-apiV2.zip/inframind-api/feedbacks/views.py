from rest_framework import generics
from feedbacks.models import Feedback
from feedbacks.serializers import FeedbackSerializer

class FeedbackCreateListView(generics.ListCreateAPIView):
    queryset = Feedback.objects.all()
    serializer_class = FeedbackSerializer

class FeedbackRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Feedback.objects.all()
    serializer_class = FeedbackSerializer