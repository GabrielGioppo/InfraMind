from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static

# Import das views
from users.views import UserCreateListView, UserRetrieveUpdateDestroyView
from categories.views import CategoryCreateListView, CategoryRetrieveUpdateDestroyView
from occurrences.views import OccurrenceCreateListView, OccurrenceRetrieveUpdateDestroyView, nearby_occurrences
from images.views import ImageCreateListView, ImageRetrieveUpdateDestroyView
from validations.views import ValidationCreateListView, validate_occurrence
from feedbacks.views import FeedbackCreateListView, FeedbackRetrieveUpdateDestroyView
from logs.views import LogCreateListView, LogRetrieveUpdateDestroyView

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),
    
    # Users endpoints
    path('api/users/', UserCreateListView.as_view(), name='user-create-list'),
    path('api/users/<int:pk>/', UserRetrieveUpdateDestroyView.as_view(), name='user-detail'),
    
    # Categories endpoints
    path('api/categories/', CategoryCreateListView.as_view(), name='category-create-list'),
    path('api/categories/<int:pk>/', CategoryRetrieveUpdateDestroyView.as_view(), name='category-detail'),
    
    # Occurrences endpoints
    path('api/occurrences/', OccurrenceCreateListView.as_view(), name='occurrence-create-list'),
    path('api/occurrences/<int:pk>/', OccurrenceRetrieveUpdateDestroyView.as_view(), name='occurrence-detail'),
    path('api/occurrences/nearby/<str:lat>/<str:lng>/', nearby_occurrences, name='nearby-occurrences'),
    path('api/occurrences/nearby/<str:lat>/<str:lng>/<int:radius_km>/', nearby_occurrences, name='nearby-occurrences-radius'),
    
    # Images endpoints
    path('api/images/', ImageCreateListView.as_view(), name='image-create-list'),
    path('api/images/<int:pk>/', ImageRetrieveUpdateDestroyView.as_view(), name='image-detail'),
    
    # Validations endpoints
    path('api/validations/', ValidationCreateListView.as_view(), name='validation-create-list'),
    path('api/validations/occurrence/<int:occurrence_id>/user/<int:user_id>/', validate_occurrence, name='validate-occurrence'),
    
    # Feedbacks endpoints
    path('api/feedbacks/', FeedbackCreateListView.as_view(), name='feedback-create-list'),
    path('api/feedbacks/<int:pk>/', FeedbackRetrieveUpdateDestroyView.as_view(), name='feedback-detail'),
    
    # Logs endpoints
    path('api/logs/', LogCreateListView.as_view(), name='log-create-list'),
    path('api/logs/<int:pk>/', LogRetrieveUpdateDestroyView.as_view(), name='log-detail'),
]

# Configuração para servir arquivos de mídia em desenvolvimento
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)