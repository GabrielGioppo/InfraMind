const screens = document.querySelectorAll('.screen');
const header = document.getElementById('top-header');
const sidebar = document.getElementById('app-sidebar');
const mainContent = document.getElementById('main-content');
const ICON_EYE_OPEN = `<svg viewBox="0 0 24 24" class="eye-icon"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>`;
const ICON_EYE_CLOSED = `<svg viewBox="0 0 24 24" class="eye-icon"><path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.82l2.92 2.92c1.51-1.26 2.7-2.89 3.44-4.74-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"/></svg>`;

function getSession() {
    return {
        name: localStorage.getItem('infraMind_session_name'),
        email: localStorage.getItem('infraMind_session_email')
    };
}

function navigateTo(screenId, id = null) {
    screens.forEach(s => s.classList.add('hidden'));
    document.getElementById(screenId).classList.remove('hidden');

    const session = getSession();

    if (['login-screen', 'register-screen'].includes(screenId)) {
        header.classList.add('hidden');
        sidebar.classList.add('hidden');
        mainContent.style.marginLeft = '0';
    } else {
        if (!session.email) { navigateTo('login-screen'); return; }
        header.classList.remove('hidden');
        sidebar.classList.remove('hidden');
        mainContent.style.marginLeft = '260px';
        document.getElementById('display-user-name').innerText = session.name;
    }

    if (screenId === 'list-screen') renderList();
    if (screenId === 'details-screen') renderDetails(id);
    if (screenId === 'edit-screen') loadEditData(id); // Carrega dados na edição
    if (screenId === 'admin-screen') renderAdmin();
    window.scrollTo(0,0);
}

function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (input.type === "password") {
        input.type = "text";
        btn.innerHTML = ICON_EYE_CLOSED;
    } else {
        input.type = "password";
        btn.innerHTML = ICON_EYE_OPEN;
    }
}

document.getElementById('register-form').onsubmit = (e) => {
    e.preventDefault();
    const name = document.getElementById('reg-name').value;
    const email = document.getElementById('reg-email').value;
    const password = document.getElementById('reg-password').value;

    const users = JSON.parse(localStorage.getItem('infraMind_users') || "[]");
    if (users.find(u => u.email === email)) { alert("E-mail já registrado no sistema."); return; }

    users.push({ name, email, password });
    localStorage.setItem('infraMind_users', JSON.stringify(users));
    localStorage.setItem('infraMind_session_name', name);
    localStorage.setItem('infraMind_session_email', email);
    navigateTo('list-screen');
};

document.getElementById('login-form').onsubmit = (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const users = JSON.parse(localStorage.getItem('infraMind_users') || "[]");
    const user = users.find(u => u.email === email && u.password === password);

    if (user) {
        localStorage.setItem('infraMind_session_name', user.name);
        localStorage.setItem('infraMind_session_email', user.email);
        navigateTo('list-screen');
    } else {
        alert("Falha na autenticação. Verifique suas credenciais.");
    }
};

function logout() {
    localStorage.removeItem('infraMind_session_name');
    localStorage.removeItem('infraMind_session_email');
    location.reload();
}

function getAllOccurrences() { return JSON.parse(localStorage.getItem('myOccurrences') || "[]"); }

// --- CRIAR ---
document.getElementById('create-form').onsubmit = async (e) => {
    e.preventDefault();
    const session = getSession();
    const file = document.getElementById('image-upload').files[0];
    let imgData = "";

    if (file) {
        imgData = await new Promise(r => {
            const reader = new FileReader();
            reader.onload = () => r(reader.result);
            reader.readAsDataURL(file);
        });
    }

    const newOcc = {
        id: Date.now(),
        ownerEmail: session.email,
        ownerName: session.name,
        title: document.getElementById('problem-title').value,
        category: document.getElementById('category').value,
        location: document.getElementById('location').value,
        description: document.getElementById('description').value,
        image: imgData,
        date: new Date().toLocaleDateString('pt-BR'),
        status: "EM ANÁLISE"
    };

    const all = getAllOccurrences();
    all.push(newOcc);
    localStorage.setItem('myOccurrences', JSON.stringify(all));
    e.target.reset();
    navigateTo('list-screen');
};
function loadEditData(id) {
    const occ = getAllOccurrences().find(o => o.id === id);
    if (!occ) return;

    document.getElementById('edit-id').value = occ.id;
    document.getElementById('edit-category').value = occ.category;
    document.getElementById('edit-problem-title').value = occ.title;
    document.getElementById('edit-location').value = occ.location;
    document.getElementById('edit-description').value = occ.description;
    
    const imgPreview = document.getElementById('edit-current-image');
    if (occ.image) {
        imgPreview.src = occ.image;
        imgPreview.style.display = "block";
    } else {
        imgPreview.style.display = "none";
    }
}

document.getElementById('edit-form').onsubmit = async (e) => {
    e.preventDefault();
    const id = Number(document.getElementById('edit-id').value);
    const file = document.getElementById('edit-image-upload').files[0];
    
    const all = getAllOccurrences();
    const index = all.findIndex(o => o.id === id);
    if (index === -1) return;
    if (file) {
        const imgData = await new Promise(r => {
            const reader = new FileReader();
            reader.onload = () => r(reader.result);
            reader.readAsDataURL(file);
        });
        all[index].image = imgData;
    }

    all[index].category = document.getElementById('edit-category').value;
    all[index].title = document.getElementById('edit-problem-title').value;
    all[index].location = document.getElementById('edit-location').value;
    all[index].description = document.getElementById('edit-description').value;

    localStorage.setItem('myOccurrences', JSON.stringify(all));
    e.target.reset(); 
    navigateTo('details-screen', id); 
};

// --- LISTA ---
function renderList() {
    const container = document.getElementById('occurrence-list');
    container.innerHTML = "";
    const session = getSession();
    const myItems = getAllOccurrences().filter(occ => occ.ownerEmail === session.email);

    if (myItems.length === 0) {
        container.innerHTML = `<div class="content-card" style="grid-column: 1/-1; text-align: center; color: #64748b; padding: 48px;">Nenhum registro encontrado no seu perfil.</div>`;
        return;
    }

    myItems.reverse().forEach(occ => {
        const div = document.createElement('div');
        div.className = "occurrence-card";
        div.innerHTML = `
            <img src="${occ.image || 'https://via.placeholder.com/400x200?text=S/IMAGEM'}" class="occ-img">
            <div class="occ-body">
                <h3>${occ.title}</h3>
                <p>${occ.location}</p>
                <div class="card-actions">
                    <button class="btn secondary-btn" style="padding: 8px 16px" onclick="navigateTo('details-screen', ${occ.id})">Acessar</button>
                    <div style="display:flex; gap: 8px;">
                        <button class="edit-btn-small" onclick="navigateTo('edit-screen', ${occ.id})">Editar</button>
                        <button class="danger-btn-small" onclick="deleteOcc(${occ.id})">Remover</button>
                    </div>
                </div>
            </div>
        `;
        container.appendChild(div);
    });
}

// --- DETALHES ---
function renderDetails(id) {
    const occ = getAllOccurrences().find(o => o.id === id);
    if (!occ) return;

    document.getElementById('detail-title').innerText = occ.title;
    document.getElementById('detail-status').innerText = occ.status;
    document.getElementById('detail-date').innerText = occ.date;
    document.getElementById('detail-location').innerText = occ.location;
    document.getElementById('detail-description').innerText = occ.description;
    document.getElementById('detail-reporter-name').innerText = "Analista: " + occ.ownerName;
    
    const imgEl = document.getElementById('detail-image');
    if (occ.image) {
        imgEl.src = occ.image;
        imgEl.style.display = "block";
    } else {
        imgEl.style.display = "none";
    }

    const actions = document.querySelector('.detail-actions');
    actions.innerHTML = `
        <button class="btn secondary-btn" onclick="navigateTo('list-screen')">Retornar à Lista</button>
        <button class="btn primary-btn" onclick="navigateTo('edit-screen', ${occ.id})">Editar Registro</button>
        <button class="btn" style="background: #fee2e2; color: #dc2626; border: 1px solid #fecaca;" onclick="deleteOcc(${occ.id})">Excluir Permanentemente</button>
    `;
}
function deleteOcc(id) {
    if (confirm("Confirmar a exclusão permanente deste registro técnico?")) {
        const filtered = getAllOccurrences().filter(o => o.id !== id);
        localStorage.setItem('myOccurrences', JSON.stringify(filtered));
        navigateTo('list-screen');
    }
}
function renderAdmin() {
    const session = getSession();
    const all = getAllOccurrences();
    document.getElementById('stat-total').innerText = all.length;
    document.getElementById('stat-user-total').innerText = all.filter(o => o.ownerEmail === session.email).length;
}

if (getSession().email) navigateTo('list-screen');
else navigateTo('login-screen');